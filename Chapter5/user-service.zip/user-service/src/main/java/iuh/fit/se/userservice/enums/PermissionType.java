package iuh.fit.se.userservice.enums;

public enum PermissionType {
    PERMISSION_READ,
    PERMISSION_WRITE,
    PERMISSION_DELETE,
    PERMISSION_UPDATE,
}
