package iuh.fit.se.userservice.services;

import iuh.fit.se.userservice.entities.Permission;

public interface PermissionService {
    void savePermission(Permission permission);
}
