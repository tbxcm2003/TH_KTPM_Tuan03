package iuh.fit.se.userservice.enums;

public enum RoleType {
    ROLE_USER,
    ROLE_ADMIN,
    ROLE_SUPER_ADMIN;
}
